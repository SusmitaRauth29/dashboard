'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import React from 'react'

const Sidebar = () => {
  const path=usePathname()  

  return (
    <div className='w-[22%] p-4'>
        <div className="logo-conatiner my-6">
        <h2>
            Dashboard.
        </h2>
        </div>
        <ul className='my-5'>
            <li className={`my-4 ${path=='/'? 'active' :''}`}><Link href="/">Dashboard</Link></li>
            <li className={`my-4 ${path=='/product'? 'active' :''}`}><Link href="/product">Product</Link></li>
            <li className={`my-4 ${path=='/customer'? 'active' :''}`}> <Link href="/customer">Customer</Link></li>
            <li className={`my-4 ${path=='/income'? 'active' :''}`}> <Link href="/income">Income</Link></li>
            <li className={`my-4 ${path=='/promote'? 'active' :''}`}> <Link href="/promote">Promote</Link></li>
            <li className={`my-4 ${path=='/help'? 'active' :''}`}> <Link href="/help">Help</Link></li>
        </ul>
    </div>
  )
}

export default Sidebar