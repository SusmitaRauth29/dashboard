import { Container } from 'postcss'
import React from 'react'
import { O1 } from '../Images'
import { O2 } from '../Images'
import { O3 } from '../Images'

const Overview = () => {
  return (
    <div className="overview-Container bg-white p-5 my-4 flex justify-between rounded-xl ">
        <div className="overview-section flex gap-2">
            <div className="icon w-16 h-16 rounded-full bg-green-200 flex justify-center items-center">
                <img src={O1.src} alt='overviewimg' width='40px'/>
            </div>
            <div className="description">
                <p>Total Customers</p>
                <h3>5423</h3>
                <p><span className='text-green-600 font-semibold '>↑16%</span> this month</p>
            </div>
        </div>
        <div className=' border-l-gray-600 border  '></div>
        <div className="overview-section flex gap-2">
            <div className="icon w-16 h-16 rounded-full bg-green-200  flex justify-center items-center">
            <img src={O2.src} alt='overviewimg' width='40px'/>
            </div>
            <div className="description">
                <p>Members</p>
                <h3>1893</h3>
                <p><span  className='text-red-700 font-semibold'>↓1%</span> this month</p>
            </div>
        </div>
        <div className=' border-l-gray-600 border  '></div>
        <div className="overview-section flex gap-2">
            <div className="icon w-16 h-16 rounded-full bg-green-200  flex justify-center items-center">
            <img src={O3.src} alt='overviewimg' width='40px'/>
            </div>
            <div className="description">
                <p>Active Now</p>
                <h3>189</h3>
            </div>
        </div>
    </div>
  )
}

export default Overview