import React from 'react'
import { Closeimg } from '../Images'

const AddCustomer = (props) => {
  const {handleModalOpen}=props;
  return (
   <div className="addModal absolute flex justify-center items-center w-screen h-screen bg-transparent">   
      <form action="post" className='p-14 bg-white grid gap-3 w-[600px] h-[500px] z-10 relative shadow-lg'>
        <button type='button' className='absolute right-0 w-max m-3' onClick={handleModalOpen}><img src={Closeimg.src} width={'30px'} height={'30px'}></img></button>
        <h2 className='text-center'>Add mode Customer</h2>
          <input className='bg-blue-100 w-full' type="text" name="" id="" placeholder='Customer name'/>
          <input  className='bg-blue-100 w-full' type="email" name="" id="" placeholder='Email Address'/>
          <input  className='bg-blue-100 w-full' type="text" name="" id="" placeholder='Phone Number'/>
          <input  className='bg-blue-100 w-full' type="text" name="" id="" placeholder='Country'/>
          <input  className='bg-blue-100 w-full' type="text" name="" id="" placeholder='Company'/>
          <button  className='bg-blue-100 w-full submitBtn' type="submit" >Submit</button>
      </form>
   </div>
  )
}

export default AddCustomer