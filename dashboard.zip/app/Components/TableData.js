
'use client'
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import AddCustomer from './AddCustomer'


const TableData = (props) => {
  const {handleModalOpen}=props; 
  const [data,setData]=useState()
  const getData =async () =>{
    const data=await axios.get('https://jsonplaceholder.typicode.com/users')
    console.log('data',data?.data)
    setData(data?.data)
  }

  useEffect(() => {
    getData()
  }, [])
  console.log('dataaaaaaaaaa',data)

  const searchData = (searchValue) =>{
    console.log(searchValue)
    console.log(
      data.filter(i=>i.findIndexOf(i.name) ))
  }

  return (
    <>
     <div className="table-container bg-white p-5 my-4  rounded-xls">
      <div className="table-title flex justify-between">
          <div className=''>
             <h2>All Customers</h2>
             <p>Active Members</p>
          </div>
          <div className='add-container'>
             <button className='w-32 h-10 bg-purple' onClick={handleModalOpen}>Add Customer</button>
          </div>
          <div className='search-container'>
             <input placeholder='search' type="search" onChange={(e)=>searchData(e.target.value)}/>
          </div>
      </div>   
     <table className='mt-8 overflow-hidden w-max'>
        <thead>
          <tr>
            <th className='w-56 text-start'>Customer Name</th>
            <th className='w-56 text-start'>Company</th>
            <th className='w-56 text-start'>Email</th>
            <th className='w-56 text-start'>Phone Number</th>
            <th>Status</th>
          </tr>
           
        </thead>
        <tbody>
          {data?.map(i=>{
            return(
              <tr className='m-10 ' key={i?.id}>
              <td>{i?.name}</td>
              <td>{i?.company?.name}</td>
              <td>{i?.email}</td>
              <td>{i?.phone}</td>
              <td><p className='bg-green-200 w-max h-max p-1 border border-green-700 rounded-xl '>Active</p></td>
          </tr>
            )
          })}
           
        </tbody>
     </table>
    </div>
    </>
   
  )
}

export default TableData