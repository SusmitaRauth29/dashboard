import React from 'react'

const Header = () => {
    return (
        <div className='flex justify-between'>
            <div className="title text-2xl font-semibold ">Hello John 👋🏼,</div>
            <div className="search-bar">
                <input className='h-[38px] w-[216px] p-4' type='search' placeholder='Search' />
            </div>
        </div>
    )
}

export default Header

