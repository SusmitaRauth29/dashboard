import Closeimg from './close.png'
import O1 from './profile-2user.png'
import O2 from './profile-tick.png'
import O3 from './monitor.png'

export {Closeimg,O1,O2,O3}