'use client'
import Image from "next/image";
import Header from "./Components/Header";
import Sidebar from "./Components/Sidebar";
import Overview from "./Components/Overview";
import TableData from "./Components/TableData";
import AddCustomer from "./Components/AddCustomer";
import { useState } from "react";
// import Table from "./Components/Table";

export default function Home() {
  const [openModal,setOpenModal]=useState(false)
  const handleModalOpen=()=>{
    setOpenModal(!openModal)
  }

  return (
      <>
      {openModal && <AddCustomer handleModalOpen={handleModalOpen}/>}
      <div>
        <Header/>
        <Overview/>
        <TableData handleModalOpen={handleModalOpen}/>
      </div>
  
   </>
  );
}
