import React from 'react'

const Layout = () => {
  return (
    <main className="main-div flex w-screen h-screen relative">
    <Sidebar/>
     <div>
      {children}
     </div>
  </main>
  )
}

export default Layout