import React from 'react'

const Page = () => {
  return (
    <div>P</div>
  )
}

export default Page